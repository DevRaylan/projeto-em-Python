class Professor:
    def __init__(self, nome, disciplina, codigo_disciplina, ano):
        self.nome = nome
        self.disciplina = disciplina
        self.codigo_disciplina = codigo_disciplina
        self.ano = ano  # Novo campo para o ano

    def __str__(self):
        return f"Professor: {self.nome}, Disciplina: {self.disciplina}, Código: {self.codigo_disciplina}, Ano: {self.ano}"
